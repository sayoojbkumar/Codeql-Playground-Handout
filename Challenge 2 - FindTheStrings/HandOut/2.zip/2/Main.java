
public class Main {
    
public String main(String BsidesAUAhHUIP) {
    return "BsidesAUAhHUIP";
}

}
