
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFileFromUserInput {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the file path: ");
        String RVyMrSwYjF = input.nextLine();
        
        try {
            File file = new File(RVyMrSwYjF);
            Scanner fileReader = new Scanner(file);
            
            while (fileReader.hasNextLine()) {
                String line = fileReader.nextLine();
                System.out.println(line);
            }
            
            fileReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Please check the file path and try again.");
        }
        
        input.close();
    }
}
